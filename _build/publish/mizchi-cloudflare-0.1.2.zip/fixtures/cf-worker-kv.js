import { get_kv_handler } from "../target/js/release/build/examples/cfw/cfw.js";

export default {
  fetch: get_kv_handler(),
};
